package com.journi.challenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JourniChallengeApplicationTests {

	@Test
	void contextLoads() {
	}

}
