# Coding challenge for Backend Development

See details here: http://blog.papauschek.com/2019/10/analytics-coding-challenge/
